﻿using System.ComponentModel.DataAnnotations;

namespace ContractMonthly.Models
{
 
    public class Claim
    {
        public int ID { get; set; }

        [Required]
        public string LecturerName { get; set; }

        [Required]
        public decimal HoursWorked { get; set; }

        [Required]
        public decimal HourlyRate { get; set; }

        public string SupportingDocumentUrl { get; set; }

        public string Status { get; set; }
    }
}
