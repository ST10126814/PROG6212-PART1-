﻿using System.ComponentModel.DataAnnotations;

namespace ContractMonthly.Models
{
    public class User
    {
        public int ID { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        public string Role { get; set; } // e.g., Lecturer, Programme Coordinator, Academic Manager
    }
}
