﻿
using Microsoft.AspNetCore.Mvc;
using ContractMonthly.Controllers;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ContractMonthly.Controllers
{
    public class ClaimsController : Controller
    {
        private static List<Claim> claims = new List<Claim>();

        public IActionResult Index()
        {
            return View(claims);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Claim claim, Microsoft.AspNetCore.Http.IFormFile supportingDocument)
        {
            if (ModelState.IsValid)
            {
                if (supportingDocument != null && supportingDocument.Length > 0)
                {
                    // Save the file to the server
                    var fileName = Path.GetFileName(supportingDocument.FileName);
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        supportingDocument.CopyTo(stream);
                    }
                    claim.SupportingDocumentUrl = $"/uploads/{fileName}";
                }

                claim.ID = claims.Count + 1;
                claim.Status = "Pending";
                claims.Add(claim);

                return RedirectToAction("Index");
            }

            return View(claim);
        }
    }
}
