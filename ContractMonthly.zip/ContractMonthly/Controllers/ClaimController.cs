﻿
using Microsoft.AspNetCore.Mvc;

namespace ContractMonthly.Controllers
{
    public class ClaimsController : Controller
    {
        public IActionResult SubmitClaim()
        {
            return View();
        }

        public IActionResult UploadDocument()
        {
            return View();
        }

        public IActionResult TrackClaim()
        {
            return View();
        }
    }
}