﻿using Microsoft.AspNetCore.Mvc;

namespace ContractMonthly.Controllers
{
  
public class ApprovalController : Controller
{
    public IActionResult ViewClaims()
    {
        return View();
    }

    public IActionResult ApprovalClaim(int id)
    {
        return View();
    }
}
}